#include "main.h"
#include "DFT.h"

 /*
 	Author: 	Dani�l Boon
	DFT Low level design V2.1
    Project groep 29 Jan 2018
	Samples worden om de 97,7 uS met de ADC gemaakt (10240Hz)
	na 512 keer samplen worden de waardes van de buffer gebruikt bij de DFT berekeningen
	wanneer de DFT berekeningen gedaan zijn, zal bij de volgende keer dat er gesampled wordt,
	tijdens het samplen, de positie van het Spaceship gestuurd worden naar de FPGA

	ADC -->channel 1
	DAC -->channel 2
 */
int i=0;						//teller om de buffer te vullen
int j=0;						//teller voor het sturen van berichten naar de FPGA
char stand=1;					//stand tusen ADC uitlezen (1), DAC uitsturen (2)
								//en aangeven wanneer het samplen (en eventueel DAC) klaar is (0)
int buffer[aantal_samples];		//buffer voor het samplen
char grootste_MAG=0;			//de grootste_MAG magnitude
char Spaceship_Positie=0;		//waarde spaceship positie om naar de FPGA te sturen

//referentie signalen voor de MUL berekeningen
int8_t ref_sin[aantal_ref+start_freq_bereken][aantal_samples];
int8_t ref_cos[aantal_ref+start_freq_bereken][aantal_samples];

uint8_t magnitude[aantal_ref+start_freq_bereken]; //array om de magnitudes in op te slaan

//waardes van ��n sinus periode
uint8_t  ref_sine_buf[] = {128,129,131,132,134,135,137,138,140,142,143,145,146,148,149,151,152,154,155,157,158,160,162,163,165,166,167,169,170,172,173,175,
		 176,178,179,181,182,183,185,186,188,189,190,192,193,194,196,197,198,200,201,202,203,205,206,207,208,210,211,212,213,214,215,217,
		 218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,234,235,236,237,238,238,239,240,241,241,242,243,243,244,245,
		 245,246,246,247,248,248,249,249,250,250,250,251,251,252,252,252,253,253,253,253,254,254,254,254,254,255,255,255,255,255,255,255,
		 255,255,255,255,255,255,255,255,254,254,254,254,254,253,253,253,253,252,252,252,251,251,250,250,250,249,249,248,248,247,246,246,
		 245,245,244,243,243,242,241,241,240,239,238,238,237,236,235,234,234,233,232,231,230,229,228,227,226,225,224,223,222,221,220,219,
		 218,217,215,214,213,212,211,210,208,207,206,205,203,202,201,200,198,197,196,194,193,192,190,189,188,186,185,183,182,181,179,178,
		 176,175,173,172,170,169,167,166,165,163,162,160,158,157,155,154,152,151,149,148,146,145,143,142,140,138,137,135,134,132,131,129,
		 128,126,124,123,121,120,118,117,115,113,112,110,109,107,106,104,103,101,100,98,97,95,93,92,90,89,88,86,85,83,82,80,
		 79,77,76,74,73,72,70,69,67,66,65,63,62,61,59,58,57,55,54,53,52,50,49,48,47,45,44,43,42,41,40,38,
		 37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,21,20,19,18,17,17,16,15,14,14,13,12,12,11,10,
		 10,9,9,8,7,7,6,6,5,5,5,4,4,3,3,3,2,2,2,2,1,1,1,1,1,0,0,0,0,0,0,0,
		 0,0,0,0,0,0,0,0,1,1,1,1,1,2,2,2,2,3,3,3,4,4,5,5,5,6,6,7,7,8,9,9,
		 10,10,11,12,12,13,14,14,15,16,17,17,18,19,20,21,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,
		 37,38,40,41,42,43,44,45,47,48,49,50,52,53,54,55,57,58,59,61,62,63,65,66,67,69,70,72,73,74,76,77,
		 79,80,82,83,85,86,88,89,90,92,93,95,97,98,100,101,103,104,106,107,109,110,112,113,115,117,118,120,121,123,124,126,};

uint32_t Data = 0;		//benodigde data voor de DAC
uint32_t Data1 = 0;
uint32_t Data2 = 250;

uint32_t Data;

//interupt functie voor het samplen (ADC en DAC)
void TIM3_IRQHandler(void)
/* TIM3 Interrupt Request Handler
 * This function is called when an TIM3 interrupt occurred.
 * Deze interupt springt aan om de 167 uS.
 * In deze functie wordt de ADC naar de buffer, of de buffer naar DAC uitgevoerd
 */
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
	{

		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);

		//als de samplebuffer vol is, wissel van stand
		#ifdef DAC_debug
		if(i>aantal_samples && stand == 2)
		{
			stand=0;
			i=0;
			j=0;
			grootste_MAG =0;
			Spaceship_Positie=0;
			TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE);
			/* TIM3 disable counter */
			TIM_Cmd(TIM3, DISABLE);
		}
		#endif
		if(i>aantal_samples && stand == 1)
		{
			#ifdef DAC_debug
			stand = 2;
			#else
			stand=0;
			TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE);
			/* TIM3 disable counter */
			TIM_Cmd(TIM3, DISABLE);
			#endif
			grootste_MAG =0;
			Spaceship_Positie = 0;
			i=0;
			j=0;
		}

		//ADC naar de samplebuffer
		if(stand==1)
		{
			buffer[i]=Get_ADC_Value(1); //zet ADC waarde in de buffer
			//UART_putint(buffer[i]); UART_puts("\t"); //debug (terminal)
		}

		//door middel van DAC de samplebuffer outputen
		if(stand==2)
		{
			if (Data1++>1024)
				Data1=0;
			DAC_SetChannel1Data(DAC_Align_12b_R, Data1);

			DAC_SetChannel2Data(DAC_Align_12b_R, buffer[i]); //zet buffer op de DAC
			//UART_printf(7,"stand2");//debug (terminal)
		}


		//volgende waarde in de samplebuffer
		//UART_printf(20,"interrupt"); //debug (terminal)
		i++;
		#ifdef  FPGA_COM
		//om de twee samples stuur een bericht (positie Spaceship of VU meter positie) naar de FPGA tot de 100 samples is bereikt;
		//grootste_MAG mag niet groter zijn dan 30, om geen witte ruis door te sturen;
		//de laatste 2 magnitude berichten, wordt niks mee gedaan bij het spel Space Invaders,
		//maar zijn nog wel nodig om het protocol aan te houden
			if((i/2)==j&&j<100&&grootste_MAG>30)
			{
				UART_putchar((Spaceship_Positie >> 4) | 0x10);
				UART_putchar((Spaceship_Positie & 0x0F) | 0x20);
				UART_putchar(magnitude[j] | 0x40);
				UART_putchar(magnitude[j] | 0x80);
				j++;
			}
		#endif
	}
}


 //functie om verhoudingen van waardes aan te passen
 int map(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max)
 {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
 }

 //benodigde funtie voor de wortel berekeningen om de magnitude te berekenen
 int powerOfTen(int num)
 {
     int rst = 10;
     if(num >= 0)
	 {
	 	int q;
         for(q = 0; q < num ; q++)
             rst = 100;
     }
	 else
	 {
	 	int q;
         for(q = 0; q < (0 - num ); q++)
            rst = 1;
    }
    return rst;
 }

//wortel berekening om de magnitude te berekenen
int squareRoot(int a)
{
     int z = a;
     int rst = 0.0;
     int max = 8;
     int q;
     int j = 1.0;
     for(q = max ; q > 0 ; q--)
     {
         // waarde moet groter zijn dan nul
         if(z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
         {
             while( z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
             {
                 j++;
                 if(j >= 10) break;
             }
             j--;
             z -= (( 2 * rst ) + ( j * powerOfTen(i)))*( j * powerOfTen(q)); //find value of z
             rst += j * powerOfTen(q);     // vind de som van a
             j = 1.0;
          }
      }

      for(q = 0 ; q >= 0 - max ; q--)
      {
          if(z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
          {
              while( z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
                  j++;
              j--;
              z -= (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)); // vind de waarde van z
              rst += j * powerOfTen(q);     // vind de som van a
              j = 1.0;
           }
      }
      // vind het nummer om elke decimaal
      return rst;
 }

//vul de 2D-array met referentie waardes voor de MUL berekeningen
void DFT_init(void)
{
		int k=0;
		int l=0;
		int m=0;

		//berekende Cos referentie signaal met ��n periode van uit de sinus
		for(m=0; m<aantal_samples; m++)
		{
			if((m<(aantal_samples/4)))
				ref_cos[0][m+(aantal_samples-(aantal_samples/4))]=ref_sine_buf[k]-128;//1;
			else
				ref_cos[0][m-(aantal_samples/4)]=ref_sine_buf[k]-128;//1;

			k=k+1+l;
			if(k>aantal_samples)
				k=k-aantal_samples;
		}

		//berekende de referentie signalen met verschillende periodes (zowel voor sin als cos)
		for(l=start_freq_bereken; l<(aantal_ref+start_freq_bereken); l++)
		{
			k=0;
			for(m=0; m<aantal_samples; m++)
			{
				ref_sin[l][m]=ref_sine_buf[k]-128;
				ref_cos[l][m]=ref_cos[0][k];

				k=k+1+l;
				if(k>aantal_samples)
					k=k-aantal_samples;
			}
		}


	#ifdef REF_debug
		for(l=0;l<74;l++)
		{
			UART_putint(l);UART_puts("***************************\n\rSpaceship_Positie\n\r");
			for(m=0;m<aantal_samples;m++)
			{
				if(ref_cos[l][m]>-1)
					{UART_putint(ref_cos[l][m]);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(Int_Negatief_naar_posief-ref_cos[l][m]); UART_puts("\n\r");}
				if(ref_sin[l][m]>-1)
					{UART_putint(ref_sin[l][m]);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(Int_Negatief_naar_posief-ref_sin[l][m]); UART_puts("\n\r");}
			}
			DELAY_s(10);
		}
	#endif
}



//enabled de timer interupt voor het samplen (eventueel de DAC) en voert de DFT berekeningen uit.
void DFT(void)
{
	//enable timer interupt voor het samplen
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
	/* TIM3 enable counter*/
	TIM_Cmd(TIM3, ENABLE);

	int k=0;
	int j=0;
	int mul_cos=0;
	int mul_sin=0;


	while(stand!=0)	//wacht tot het samplen klaar is
		DELAY_us(1);

	#ifdef EndPulse_debug
		DAC_SetChannel2Data(DAC_Align_12b_R, 2000);
	#endif

	#ifdef MAG_debug
		UART_printf(40,"stop sample, door met code\n\r");
	#endif

	for (j=0;j<aantal_samples;j++)	//zet de samplewaardes om in een kleinere waarde (ander gaan de MUL antwoorden overflowen)
	{
		buffer[j]=buffer[j]-2048;
		buffer[j]=map(buffer[j],-2048,2048,-128,128);

		#ifdef BUF_debug
		if(buffer[j]>-1)
			{UART_putint(buffer[j]);UART_puts("\n\r");}
		else
			{UART_puts("-");UART_putint(Int_Negatief_naar_posief-buffer[j]); UART_puts("\n\r");}
		#endif
	}

	for(j=start_freq_bereken;j<(aantal_ref+start_freq_bereken); j++) //om elke j ophoging wordt een nieuwe magnitude bepaald
	{
		mul_sin=0;
		mul_cos=0;

		for(k=0;k<aantal_samples;k++) //voer de MUL berekeningen uit met de sample waardes en de referentie signalen
		{
			mul_sin=buffer[k]*ref_sin[j][k]+mul_sin;
			mul_cos=buffer[k]*ref_cos[j][k]+mul_cos;
		}

		#ifdef MUL_debug
			if(mul_cos>-1)
				{UART_putint(mul_cos);UART_puts("\n\r");}
			else
				{UART_puts("-");UART_putint(Int_Negatief_naar_posief-mul_cos); UART_puts("\n\r");}

			if(mul_sin>-1)
				{UART_putint(mul_sin);UART_puts("\n\r");}
			else
				{UART_puts("-");UART_putint(Int_Negatief_naar_posief-mul_sin); UART_puts("\n\r");}
		#endif

		//MUL waarden verslagen, anders wordt de magnitude te groot om als int8 op te slaan
		 mul_sin=mul_sin>>14;
		 mul_cos=mul_cos>>14;


		#ifdef MUL_debug
			if(mul_cos>-1)
				{UART_putint(mul_cos);UART_puts("\n\r");}
			else
				{UART_puts("-");UART_putint(Int_Negatief_naar_posief-mul_cos); UART_puts("\n\r");}

			if(mul_sin>-1)
				{UART_putint(mul_sin);UART_puts("\n\r");}
			else
				{UART_puts("-");UART_putint(Int_Negatief_naar_posief-mul_sin); UART_puts("\n\r");}
		#endif

		//berekening magnitude met pytagoras
		magnitude[j]= squareRoot((mul_sin*mul_sin)+(mul_cos*mul_cos));

		#ifdef MAG_debug
			UART_printf(8,"Hz ");
			UART_printf(256,"%d",20+j*20);
			UART_printf(200,"magnitude ");
			UART_putint(magnitude[j]);
			UART_puts("\n\r");
		#endif

		if(magnitude[j]>grootste_MAG)	//sla de magnitude waarde op, en bepaal het spaceship positie
		{
			grootste_MAG = magnitude[j];
			Spaceship_Positie=j-start_freq_bereken;
		}
	}
	#ifdef MAG_debug
		UART_printf(40,"done!\n\r************************************\n\r");
		DELAY_ms(5000);
		UART_printf(40,"samplen begonnen\n\r");
	#endif

	stand = 1;

	#ifdef EndPulse_debug
		DAC_SetChannel2Data(DAC_Align_12b_R, 0);
	#endif
}
