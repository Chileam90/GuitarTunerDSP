

#define		RTC1		1
#define		RTC_SET		1
#define		AD			1
#define		DA			1
#define 	UART		1
#define		LCD			1
#define		DELAY		1
#define		KEYS_INT	1
#define 	DFTtje		1

#include "stm32f4xx.h"
#include "stm32f4xx_conf.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_syscfg.h"
#include "stm32f4xx_pwr.h"
#include "misc.h"
#include <stdio.h>
#include <stdarg.h>


#if DFTtje
#include "DFT.h"
#endif

#if	RTC1
#include "stm32f4xx_rtc.h"
#include "rtc.h"
#endif

#if AD
#define	TIMER 1
#include "stm32f4xx_adc.h"
#include "adc.h"
#endif

#if DA
#define	TIMER 1
#include "stm32f4xx_dac.h"
#include "dac.h"
#endif

#if UART
#include "stm32f4xx_usart.h"
#include "uart.h"
#endif

#if KEYS_INT
#define	EXTINT	1
#include "keys_int.h"
#endif

#if LCD
#include "lcd.h"
#endif

#if DELAY
#include "delay.h"
#endif

#if EXTINT
#include "stm32f4xx_exti.h"
#endif

#if TIMER
#include "stm32f4xx_tim.h"
#endif


extern void UART_putint(unsigned int num);
extern void UART_putnum(unsigned int num, unsigned char deel);


