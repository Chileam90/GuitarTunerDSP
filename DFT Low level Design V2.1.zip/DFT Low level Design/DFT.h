 /*
 	Author: 	Dani�l Boon
	DFT Low level design V2.1
    Project groep 29 Jan 2018
	Samples worden om de 167 uS met de ADC gemaakt (10240Hz)
	na 512 keer samplen worden de waardes van de buffer

	ADC -->channel 1
	DAC -->channel 2
 */

void TIM3_IRQHandler(void);
void DFT_init(void);
void DFT(void);

int powerOfTen(int num);
int squareRoot(int a);
int map(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max);

//#define DAC_debug 	//uncomment om op de DAC de sample waardes van de buffer te krijgen
//#define REF_debug 	//uncomment om op de terminal de referentie signalen te controleren
//#define BUF_debug 	//uncomment om op de terminal de buffer waardes te controleren
//#define MUL_debug 	//uncomment om op de terminal de uitkomsten van de MUL berekeningen te controleren
#define MAG_debug 	//uncomment om op de terminal de magnitude waardes te controleren
#define EndPulse_debug	//uncomment om op de DAC een pulse te zien, hoe lang de ARM bezig is met de DFT berekeningen
//#define FPGA_COM		//uncomment om de communicatie met de FPGA mogelijk te maken (voor het door sturen van de Spaceship posities)

#define aantal_ref	20 //max 100 met start_freq = 20
#define aantal_samples	512
#define start_freq	300  //min 20
#define Int_Negatief_naar_posief	4294967296 //nodig om een negatieve waarde op UART_putint() te printen

#define start_freq_bereken ((start_freq-20)/20) //zet de waarde start_freq om in een gebruikbare waarde
