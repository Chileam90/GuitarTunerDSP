
#include "main.h"
#include "stdint.h"

extern uint32_t G_CLK;



int main(void)
{
	char *version = "DFT";	// Showed on LCD at startup

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	GPIOD -> MODER |= ( 1 << 26 );
	GPIOD -> MODER |= ( 1 << 30 );

	static int set=1;		// reset identifier

	SystemInit();			// Set SystemCLK
	set++;					// if this value is > 1 you have made a serious pointer error, reset happened
	DELAY_init();			// Initialise Delay functions

	UART_init();			// Initialise UART3 Without interrupt

	UART_INT_init();		// Initialise UART3 With interrupt enabled (Also use UART_init())

	LCD_init();				// Initialise LCD-display

	LCD_clear();			// Start with a clear display
	LCD_XY(0,0);			// Shift one spot
	LCD_put(version);		// Put the version

	DAC_init(Channel_1);	// init channel 1 of DA converter full precision

	DAC_INT_init();			// interupt instellen (op 6kHz)

	ADC_init(Channel_1);	// init channel 1 of AD converter full precision
	ADC_init(Channel_2);	// init channel 2 of AD converter full precision

	DFT_init();				//initialiseer referentie signalen van de DFT

	while(1) 				// AD/DA will run under interrupt
	{
		DFT();				//voer oneindig lang de DFT uit
	}
}
