
#include "main.h"
#include "stdint.h"
/* 	DFT Low level design V1.0
 *  Project groep 17 Nov 2018
	Samples worden om de 167 uS met de ADC gemaakt (6kHz)
	na 600 keer samplen worden de waardes van de buffer naar de DAC gestuurd op dezelfde freqentie

	ADC -->channel 1
	DAC -->channel 2
 */
extern uint32_t G_CLK;



int main(void)
{
	char *functionality =
	"ARM-board v2 \r\
	CLK speed: %d Mhz\r\r";		// Showed on UART3 at startup
	char *version = "DFT'tje";	// Showed on LCD at startup

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	GPIOD -> MODER |= ( 1 << 26 );
	GPIOD -> MODER |= ( 1 << 30 );

	static int set=1;		// reset identifier

	SystemInit();			// Set SystemCLK
	set++;					// if this value is > 1 you have made a serious pointer error, reset happened
	DELAY_init();			// Initialise Delay functions

	UART_init();			// Initialise UART3 Without interrupt
	//UART_printf(256,functionality,G_CLK/1000000);

	UART_INT_init();		// Initialise UART3 With interrupt enabled (Also use UART_init())

	LCD_init();				// Initialise LCD-display

	//PWM_init();			// Initialise PWM modulation -> Maybe not needed

	LCD_clear();			// Start with a clear display
	LCD_XY(0,0);			// Shift one spot
	LCD_put(version);		// Put the version

	DAC_init(Channel_1);	// init channel 1 of DA converter full precision
	DAC_init(Channel_2);	// init channel 2 of DA converter full precision

	DAC_INT_init();			// interupt instellen (op 6kHz)

	ADC_init(Channel_1);	// init channel 1 of AD converter full precision
	ADC_init(Channel_2);	// init channel 2 of AD converter full precision

	//UART_printf(5,"vast");

	DFT_init();

	while(1) 				// AD/DA will run under interrupt
	{
		DFT();

		TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
		/* TIM3 enable counter*/
		TIM_Cmd(TIM3, ENABLE);
		//de main loop voor andere taken (UART taken zijn verboden als er NIET gedebuged wordt!!!)
	}
}
