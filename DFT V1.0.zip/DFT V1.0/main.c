
#include "main.h"
#include "stdint.h"
/* 	DFT High level design V1.0
 *  Project groep 23 Jan 2018
	Samples worden om de 97,7 uS met de ADC gemaakt (10240Hz)
	na 512 keer samplen worden de waardes van de buffer naar de DAC gestuurd op dezelfde freqentie

	ADC -->channel 1
	DAC -->channel 2
 */

#define aantal_ref	100
#define aantal_samples	512

extern uint32_t G_CLK;

uint32_t Data = 0;
uint32_t Data1 = 0;
uint32_t Data2 = 250;

uint32_t Data;

int i=0;
int j=0;
int done=5;
char stand=1;
int buffer[aantal_samples];
uint16_t magnitude[aantal_ref];

uint8_t  ref_sine_buf[] = {128,129,131,132,134,135,137,138,
		 140,142,143,145,146,148,149,151,
		 152,154,155,157,158,160,162,163,
		 165,166,167,169,170,172,173,175,
		 176,178,179,181,182,183,185,186,
		 188,189,190,192,193,194,196,197,
		 198,200,201,202,203,205,206,207,
		 208,210,211,212,213,214,215,217,
		 218,219,220,221,222,223,224,225,
		 226,227,228,229,230,231,232,233,
		 234,234,235,236,237,238,238,239,
		 240,241,241,242,243,243,244,245,
		 245,246,246,247,248,248,249,249,
		 250,250,250,251,251,252,252,252,
		 253,253,253,253,254,254,254,254,
		 254,255,255,255,255,255,255,255,
		 255,255,255,255,255,255,255,255,
		 254,254,254,254,254,253,253,253,
		 253,252,252,252,251,251,250,250,
		 250,249,249,248,248,247,246,246,
		 245,245,244,243,243,242,241,241,
		 240,239,238,238,237,236,235,234,
		 234,233,232,231,230,229,228,227,
		 226,225,224,223,222,221,220,219,
		 218,217,215,214,213,212,211,210,
		 208,207,206,205,203,202,201,200,
		 198,197,196,194,193,192,190,189,
		 188,186,185,183,182,181,179,178,
		 176,175,173,172,170,169,167,166,
		 165,163,162,160,158,157,155,154,
		 152,151,149,148,146,145,143,142,
		 140,138,137,135,134,132,131,129,
		 128,126,124,123,121,120,118,117,
		 115,113,112,110,109,107,106,104,
		 103,101,100,98,97,95,93,92,
		 90,89,88,86,85,83,82,80,
		 79,77,76,74,73,72,70,69,
		 67,66,65,63,62,61,59,58,
		 57,55,54,53,52,50,49,48,
		 47,45,44,43,42,41,40,38,
		 37,36,35,34,33,32,31,30,
		 29,28,27,26,25,24,23,22,
		 21,21,20,19,18,17,17,16,
		 15,14,14,13,12,12,11,10,
		 10,9,9,8,7,7,6,6,
		 5,5,5,4,4,3,3,3,
		 2,2,2,2,1,1,1,1,
		 1,0,0,0,0,0,0,0,
		 0,0,0,0,0,0,0,0,
		 1,1,1,1,1,2,2,2,
		 2,3,3,3,4,4,5,5,
		 5,6,6,7,7,8,9,9,
		 10,10,11,12,12,13,14,14,
		 15,16,17,17,18,19,20,21,
		 21,22,23,24,25,26,27,28,
		 29,30,31,32,33,34,35,36,
		 37,38,40,41,42,43,44,45,
		 47,48,49,50,52,53,54,55,
		 57,58,59,61,62,63,65,66,
		 67,69,70,72,73,74,76,77,
		 79,80,82,83,85,86,88,89,
		 90,92,93,95,97,98,100,101,
		 103,104,106,107,109,110,112,113,
		 115,117,118,120,121,123,124,126,};

#define DAC_debug
//#define REF_debug
//#define BUF_debug
//#define MUL_debug
//#define MAG_debug
#define EndPulse_debug
#define FPGA_COM

int powerOfTen(int num);
int squareRoot(int a);
int map(int x, int in_min, int in_max, int out_min, int out_max);

int map(int x, int in_min, int in_max, int out_min, int out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

 int powerOfTen(int num)
 {
     int rst = 10;
     if(num >= 0)
	 {
	 	int q;
         for(q = 0; q < num ; q++)
             rst = 100;
     }
	 else
	 {
	 	int q;
         for(q = 0; q < (0 - num ); q++){
            rst = 1;
     }
    }
    return rst;
 }

int squareRoot(int a)
{
           //find more detail of this method on wiki methods_of_computing_square_roots

           //*** Babylonian method cannot get exact zero but approximately value of the square_root

     int z = a;
     int rst = 0.0;
     int max = 8;     // to define maximum digit
     int q;
     int j = 1.0;
     for(q = max ; q > 0 ; q--)
     {
         // value must be bigger then 0
         if(z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
         {
             while( z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
             {
                 j++;
                 if(j >= 10) break;
             }
             j--; //correct the extra value by minus one to j
             z -= (( 2 * rst ) + ( j * powerOfTen(i)))*( j * powerOfTen(q)); //find value of z
             rst += j * powerOfTen(q);     // find sum of a
             j = 1.0;
          }
      }

      for(q = 0 ; q >= 0 - max ; q--)
      {
          if(z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
          {
              while( z - (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)) >= 0)
                  j++;
              j--;
              z -= (( 2 * rst ) + ( j * powerOfTen(q)))*( j * powerOfTen(q)); //find value of z
              rst += j * powerOfTen(q);     // find sum of a
              j = 1.0;
           }
      }
      // find the number on each digit
      return rst;
 }


//interupt functie
void TIM3_IRQHandler(void)
/* TIM3 Interrupt Request Handler
 * This function is called when an TIM3 interrupt occurred.
 * Deze interupt springt aan om de 167 uS.
 * In deze functie wordt de ADC naar de buffer, of de buffer naar DAC uitgevoerd
 */
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
	{

		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);

		//als de buffer vol is, wissel van stand
		#ifdef DAC_debug
		if(i>aantal_samples && stand == 2)
		{
			done=1;
			i=0;
			j=0;
			TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE);
			/* TIM3 disable counter */
			TIM_Cmd(TIM3, DISABLE);

		}
		#endif
		if(i>aantal_samples && stand == 1)
		{
			#ifdef DAC_debug
			stand = 2;
			#else
			done=1;
			TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE);
			/* TIM3 disable counter */
			TIM_Cmd(TIM3, DISABLE);
			#endif
			i=0;
		}

		//ADC naar de buffer
		if(stand==1)
		{
			buffer[i]=Get_ADC_Value(1); //zet ADC waarde in de buffer
			//UART_putint(buffer[i]); UART_puts("\t"); //debug (terminal)
		}

		//door middel van DAC de buffer outputen
		if(stand==2)
		{
			if (Data1++>1024)
				Data1=0;
			DAC_SetChannel1Data(DAC_Align_12b_R, Data1);

			DAC_SetChannel2Data(DAC_Align_12b_R, buffer[i]); //zet buffer op de DAC
			//UART_printf(7,"stand2");//debug (terminal)
		}


		//volgende waarde in de buffer
		//UART_printf(20,"interrupt"); //debug (terminal)
		i++;

		#ifdef  FPGA_COM
			if((i/2)==j&&j<100)
			{
				UART_putchar((j >> 4) | 0x10);
				UART_putchar((j & 0x0F) | 0x02);
				UART_putchar((uint8_t) (magnitude[j] >> 4) | 0x40);
				UART_putchar((uint8_t) (magnitude[j] & 0x0F) | 0x80);
				j++;
			}
		#endif
	}
}

int8_t ref_sin[aantal_ref][aantal_samples];
int8_t ref_cos[aantal_ref][aantal_samples];

int main(void)
{
	char *functionality =
	"ARM-board v2 \r\
	CLK speed: %d Mhz\r\r";		// Showed on UART3 at startup
	char *version = "DFT'tje";	// Showed on LCD at startup

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	GPIOD -> MODER |= ( 1 << 26 );
	GPIOD -> MODER |= ( 1 << 30 );

	static int set=1;		// reset identifier

	SystemInit();			// Set SystemCLK
	set++;					// if this value is > 1 you have made a serious pointer error, reset happened
	DELAY_init();			// Initialise Delay functions

	UART_init();			// Initialise UART3 Without interrupt
	UART_printf(256,functionality,G_CLK/1000000);

	UART_INT_init();		// Initialise UART3 With interrupt enabled (Also use UART_init())

	LCD_init();				// Initialise LCD-display

	//PWM_init();			// Initialise PWM modulation -> Maybe not needed

	LCD_clear();			// Start with a clear display
	LCD_XY(0,0);			// Shift one spot
	LCD_put(version);		// Put the version

	DAC_init(Channel_1);	// init channel 1 of DA converter full precision
	DAC_init(Channel_2);	// init channel 2 of DA converter full precision

	DAC_INT_init();			// interupt instellen (op 6kHz)

	ADC_init(Channel_1);	// init channel 1 of AD converter full precision
	ADC_init(Channel_2);	// init channel 2 of AD converter full precision

	UART_printf(5,"vast");

	int i=0;
	int k=0;
	int j=0;
	int mul_cos=0;
	int mul_sin=0;

	for(i=0; i<aantal_ref; i++)
	{
		k=0;
		for(j=0; j<aantal_samples; j++)
		{
			ref_sin[i][j]=ref_sine_buf[k]-128;

			if((j<(aantal_samples/4))&&(i==0))
				ref_cos[i][j+(aantal_samples-(aantal_samples/4))]=ref_sine_buf[k]-128;//1;
			else if(i==0)
				ref_cos[i][j-(aantal_samples/4)]=ref_sine_buf[k]-128;//1;
			else ref_cos[i][j]=ref_cos[0][k];

			k=k+1+i;
			if(k>aantal_samples)
				k=k-aantal_samples;
		}
	}


#ifdef REF_debug
	for(i=0;i<74;i++)
	{
		UART_putint(i);UART_puts("***************************\n\rHZ\n\r");
		for(j=0;j<aantal_samples;j++)
		{
			//if(ref_cos[i][j]>-1)
			//	{UART_putint(ref_cos[i][j]);UART_puts("\n\r");}
			//else
			//	{UART_puts("-");UART_putint(4294967296-ref_cos[i][j]); UART_puts("\n\r");}
			if(ref_sin[i][j]>-1)
				{UART_putint(ref_sin[i][j]);UART_puts("\n\r");}
			else
				{UART_puts("-");UART_putint(4294967296-ref_sin[i][j]); UART_puts("\n\r");}
		}
		DELAY_s(10);
	}
#endif

	while(1) 				// AD/DA will run under interrupt
	{
		while(done==5)
			DELAY_us(1);

		#ifdef EndPulse_debug
			DAC_SetChannel2Data(DAC_Align_12b_R, 2000);
		#endif

		#ifdef MAG_debug
			UART_printf(40,"stop sample, door met code\n\r");
		#endif

		int j;
		for (j=0;j<aantal_samples;j++)
		{
			buffer[j]=buffer[j]-2048;
			buffer[j]=map(buffer[j],-2048,2048,-128,128);

			#ifdef BUF_debug
			if(buffer[j]>-1)
				{UART_putint(buffer[j]);UART_puts("\n\r");}
			else
				{UART_puts("-");UART_putint(4294967296-buffer[j]); UART_puts("\n\r");}
			#endif
		}

		for(j=0;j<aantal_ref; j++)
		{
			mul_sin=0;
			mul_cos=0;
			for(k=0;k<aantal_samples;k++)
			{
				mul_sin=buffer[k]*ref_sin[j][k]+mul_sin;

				/*#ifdef MUL_debug
				if(ref_sin[j][k]>-1)
					{UART_putint(ref_sin[j][k]);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(4294967296-ref_sin[j][k]); UART_puts("\n\r");}
				//UART_putint(mul_sin);
				#endif*/
			}

			for(k=0;k<aantal_samples;k++)
			{
				mul_cos=buffer[k]*ref_cos[j][k]+mul_cos;

				/*if(mul_cos>-1)
					{UART_putint(mul_cos);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(4294967296-mul_cos); UART_puts("\n\r");}
				if(mul_sin>-1)*/
			}

			#ifdef MUL_debug
				if(mul_cos>-1)
					{UART_putint(mul_cos);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(4294967296-mul_cos); UART_puts("\n\r");}

				if(mul_sin>-1)
					{UART_putint(mul_sin);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(4294967296-mul_sin); UART_puts("\n\r");}
			#endif

			//MUL waarden verslagen, anders wordt de magnitude te groot om als int op te slaan
			 mul_sin=mul_sin>>14;
			 mul_cos=mul_cos>>14;


			#ifdef MUL_debug
				if(mul_cos>-1)
					{UART_putint(mul_cos);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(4294967296-mul_cos); UART_puts("\n\r");}

				if(mul_sin>-1)
					{UART_putint(mul_sin);UART_puts("\n\r");}
				else
					{UART_puts("-");UART_putint(4294967296-mul_sin); UART_puts("\n\r");}
			#endif

			//berekening magnitude
			magnitude[j]= squareRoot((mul_sin*mul_sin)+(mul_cos*mul_cos));

			#ifdef MAG_debug
				UART_printf(8,"Hz ");
				UART_printf(256,"%d",20+j*20);
				UART_printf(200,"magnitude ");
				UART_putint(magnitude[j]);
				UART_puts("\n\r");
			#endif
		}
		#ifdef MAG_debug
			UART_printf(40,"done!\n\r************************************\n\r");
			//DELAY_ms(5000);
			UART_printf(40,"samplen begonnen\n\r");
		#endif
		done=5;
		stand = 1;
		i=0;

		#ifdef EndPulse_debug
			DAC_SetChannel2Data(DAC_Align_12b_R, 0);
		#endif
			//j=0;
		TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
		/* TIM3 enable counter*/
		TIM_Cmd(TIM3, ENABLE);
		//de main loop voor andere taken (UART taken zijn verboden als er NIET gedebuged wordt!!!)
	}
}
